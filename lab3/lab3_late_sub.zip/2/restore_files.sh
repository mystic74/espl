cp ../1/t_file .
cp ../1/t_file2 .
