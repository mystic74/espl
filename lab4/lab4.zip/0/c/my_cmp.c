int my_cmp(char ch1, char ch2){
	
	return (ch1 > ch2)? 1 : 2;
}