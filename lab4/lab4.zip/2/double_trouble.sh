./scmp_asm $1 $2
./scmp_c $1 $2
